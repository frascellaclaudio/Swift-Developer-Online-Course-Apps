//
//  ViewController.swift
//  Calculator
//
//  Created by Frascella Claudio on 6/26/17.
//  Copyright © 2017 TeamDecano. All rights reserved.
//
// lectures from Developing iOS 10 Apps in Swift 
// - Stanford Instructor: Paul Hegarty
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var display: UILabel!
    
    @IBOutlet weak var descriptionDisplay: UILabel!
    
    var userIsInTheMiddleOfTyping = false
    
    @IBAction func touchDigit(_ sender: UIButton) {
        let digit = sender.currentTitle!
        
        if userIsInTheMiddleOfTyping {
            if (digit == "." && display.text!.contains(".")) ||
                (display.text!.contains(".") && display.text!.characters.count == 11) ||
                (!(display.text!.contains(".")) && display.text!.characters.count == 10) {
                return
            }
            let textCurrentlyInDisplay = display.text! == "0" && digit != "." ? "" : display.text!
            display.text = textCurrentlyInDisplay + digit
        } else {
            display.text = (digit == ".") ? ("0" + digit) : digit
            userIsInTheMiddleOfTyping = true
        }
    }

    //computed property
    var displayValue: Double {
        get {
            let displayText = Double(display.text!) ?? 0
            return displayText
        }
        set {
            // to do remove decimal if it has no floating point
            if newValue.truncatingRemainder(dividingBy: 1) == 0 {
                display.text = String(format: "%.0f", newValue)
            } else {
                display.text = newValue.isNaN ? "Not a number" : String(newValue)
            }
        }
    }
    
    private var brain = CalculatorBrain() // create instance
    
    @IBAction func performOperation(_ sender: UIButton) {
        
        if display.text == "Not a number" && sender.currentTitle != "C" {
            return
        }
        
        if userIsInTheMiddleOfTyping {
            brain.setOperand(displayValue)
            userIsInTheMiddleOfTyping = false
        }
        
        if let mathematicalSymbol = sender.currentTitle {
            brain.performOperation(mathematicalSymbol)
        }
        
        // display
        displayValue = brain.result ?? 0

        // description
        descriptionDisplay.text = brain.description ?? " "
        if descriptionDisplay.text != " " {
            descriptionDisplay.text?.append(brain.resultIsPending ? "..." : " =")
        }
    }
}

