//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Frascella Claudio on 6/27/17.
//  Copyright © 2017 TeamDecano. All rights reserved.
//

//optional is an enum

import Foundation

func factorial(_ base: Double) -> Double {
    if base.truncatingRemainder(dividingBy: 1) != 0 {
        return nan("")
    } else if base == 0 {
        return 1
    } else {
        return base * factorial((base - 1))
    }
}

struct CalculatorBrain {
    
    //internal implementation
    private var accumulator: Double?
    private var descriptionAccumulator: String?
    
    //memory
    private var memory: Double = 0
    
    // optional bc we know it's not set so <?>
    
    private enum Operation { //embedded private enum
        case constant(Double) //associated value
        case unaryOperation(((Double) -> Double), ((String) -> String)) //type that takes a double and returns a double
        case binaryOperation(((Double,Double) -> Double), ((String,String) -> String))
        case equals
        case clear
        case memory
    }
    
    //dictionary of constants
    private var operations: Dictionary<String,Operation> = [
        "C"    : Operation.clear,
        
        "π"   : Operation.constant(Double.pi),
        "e"   : Operation.constant(M_E),
        
        "%"   : Operation.unaryOperation( { $0 / 100 }, { "(\($0))%" }),
        "√"   : Operation.unaryOperation(sqrt, { "√(\($0))" }),
        "cos" : Operation.unaryOperation(cos, { "cos(\($0))" }),
        "sin" : Operation.unaryOperation(sin, { "sin(\($0))" }),
        "tan" : Operation.unaryOperation(tan, { "tan(\($0))" }),
        "10ˣ" : Operation.unaryOperation(__exp10, {"10^(\($0))" }),
        "x²"  : Operation.unaryOperation( {pow(2, $0)}, { "(\($0))^2" }),
        "1/x" : Operation.unaryOperation( { 1 / $0 }, { "1/(\($0))" } ),
        "x!"  : Operation.unaryOperation(factorial, { "(\($0))!" }),
        "±"   : Operation.unaryOperation( { -$0 }, { "-(\($0))" } ),
    
        "×"   : Operation.binaryOperation( { $0 * $1 }, { "\($0) × \($1)" } ),
        "÷"   : Operation.binaryOperation( { $0 / $1 }, { "\($0) ÷ \($1)" } ),
        "+"   : Operation.binaryOperation( { $0 + $1 }, { "\($0) + \($1)" } ),
        "-"   : Operation.binaryOperation( { $0 - $1 }, { "\($0) - \($1)" } ),
        "xʸ"  : Operation.binaryOperation(pow, { "\($0)^\($1)" }),
        "EE"  : Operation.binaryOperation( { $0 * __exp10($1) }, { "\($0)×10^\($1)" } ),
        
        "="   : Operation.equals,
        
        "m+"  : Operation.memory,
        "m-"  : Operation.memory,
        "mr"  : Operation.memory,
        "mc"  : Operation.memory

    ]
    
    //closures - function embedded right in line your code
    //inference of type
    
    //public methods
    mutating func performOperation(_ symbol: String) {
        if let operation = operations[symbol] {
            switch operation {
            case .clear:
                pendingBinaryOperation = nil
                descriptionAccumulator = nil
                accumulator = nil

            case .constant(let value):
                accumulator = value
                descriptionAccumulator = symbol
                
            case .unaryOperation(let function, let funcEquation):
                if accumulator != nil { //protects crashing
                    if symbol == "%" {
                        performPendingBinaryOperation()
                    }
                    accumulator = function(accumulator!)
                    descriptionAccumulator = funcEquation(descriptionAccumulator!)
                }

            case .binaryOperation(let function, let descriptionFunction):
                if accumulator != nil {
                    performPendingBinaryOperation()
                    pendingBinaryOperation = PendingBinaryOperation(function: function,
                                                                    firstOperand: accumulator!,
                                                                    descriptionFunction: descriptionFunction,
                                                                    descriptionFirstOperand: descriptionAccumulator!)
                    accumulator = nil
                }

            case .equals:
                performPendingBinaryOperation()
            
            case .memory:
                memoryFunction(symbol)
            }
        }
    }
    
    private mutating func memoryFunction(_ symbol: String) {
        descriptionAccumulator = " "
        switch symbol {
        case "m+":
            memory = memory + accumulator!
        case "m-":
            memory = memory - accumulator!
        case "mr": 
            setOperand(memory)
        case "mc":
            memory = 0
        default:
            break
        }
    }

    private mutating func performPendingBinaryOperation() {
        if pendingBinaryOperation != nil && accumulator != nil {
            accumulator = pendingBinaryOperation!.perform(with: accumulator!)
            descriptionAccumulator = pendingBinaryOperation!.descriptionPerform(with: descriptionAccumulator!)
            pendingBinaryOperation = nil
        }
    }
    
    private var pendingBinaryOperation: PendingBinaryOperation? //optional, not set always
    
    //embedded private structures
    private struct PendingBinaryOperation {
        let function: (Double,Double) -> Double
        let firstOperand: Double
        func perform(with secondOperand: Double) -> Double {
            return function(firstOperand,secondOperand)
        }
        
        //description
        let descriptionFunction: (String,String) -> String
        let descriptionFirstOperand: String
        func descriptionPerform(with descriptionSecondOperand: String) -> String {
            return descriptionFunction(descriptionFirstOperand, descriptionSecondOperand )
        }
    }
    
    mutating func setOperand(_ operand: Double) {
        accumulator = operand
        descriptionAccumulator = operand.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", operand) : String(operand)
    }
    
    //computed property - read only property
    // returns value of accumulator
    var result: Double? { // optional bc it's not always set
        get {
            return accumulator
        }
    }
    
    //returns a description of the sequence of operands and operations that led to the value returned by result (or the result so far if resultIsPending)
    var description: String? {
        get {
            if pendingBinaryOperation == nil {
                return descriptionAccumulator
            } else {
                return pendingBinaryOperation!.descriptionPerform(with: "")

            }
        }
    }
    
    //returns true when there is a binary operation pending.
    var resultIsPending: Bool {
        get {
            return (pendingBinaryOperation !=  nil)
        }
    }
}
